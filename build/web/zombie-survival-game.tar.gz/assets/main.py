from game import Game

game = Game()
game.new()
game.run()